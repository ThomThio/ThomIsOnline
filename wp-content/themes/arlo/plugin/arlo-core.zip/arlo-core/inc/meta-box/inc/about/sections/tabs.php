<?php
/**
 * Tabs navigation.
 *
 * @package    Meta Box
 * @subpackage MB Custom Post Type
 */

?>
<h2 class="nav-tab-wrapper">
	<a href="#getting-started" class="nav-tab nav-tab-active"><?php esc_html_e( 'Getting Started', 'meta-box' ); ?></a>
</h2>
